#ifndef VERTEX
#define VERTEX

struct Vertex{
    float x;
    float y;
    float z;
    float r;
    float g;
    float b;
};

#endif // VERTEX


